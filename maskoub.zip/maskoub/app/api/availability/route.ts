import { NextRequest, NextResponse } from "next/server";
import { BRANCHES, ITEMS, state, key, type Notice } from "@/lib/store";

export async function POST(req: NextRequest) {
  const b = await req.json();
  const item = ITEMS.find((i) => i.id === b.itemId);
  const branch = BRANCHES.find((x) => x.id === b.branchId);
  if (!item || !branch) return NextResponse.json({ error: "صنف أو فرع غير صحيح" }, { status: 400 });

  const by = String(b.by || "كاشير").slice(0, 40);
  const at = new Date().toISOString();
  const reason = String(b.reason || "").trim().slice(0, 200);

  if (b.available) {
    delete state.off[key(branch.id, item.id)];
  } else {
    if (!reason) return NextResponse.json({ error: "اذكر سبب عدم التوفر" }, { status: 400 });
    state.off[key(branch.id, item.id)] = { reason, by, at };
  }

  const notice: Notice = {
    id: crypto.randomUUID(), itemId: item.id, itemName: item.name, branchId: branch.id, branchName: branch.name,
    reason: b.available ? "عاد الصنف للتوفر" : reason, by, kind: b.available ? "on" : "off", at, read: false,
  };
  state.notices.unshift(notice);
  return NextResponse.json({ ok: true, notice });
}
