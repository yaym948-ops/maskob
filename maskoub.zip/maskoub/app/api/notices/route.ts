import { NextRequest, NextResponse } from "next/server";
import { BRANCHES, ITEMS, state, key } from "@/lib/store";

export const dynamic = "force-dynamic";

export function GET() {
  const offNow = BRANCHES.flatMap((br) =>
    ITEMS.filter((i) => state.off[key(br.id, i.id)]).map((i) => ({
      itemName: i.name, branchName: br.name, ...state.off[key(br.id, i.id)],
    }))
  );
  return NextResponse.json({ notices: state.notices.slice(0, 100), offNow });
}

export async function POST(req: NextRequest) {
  const { id } = await req.json().catch(() => ({}));
  state.notices.forEach((n) => { if (!id || n.id === id) n.read = true; });
  return NextResponse.json({ ok: true });
}
