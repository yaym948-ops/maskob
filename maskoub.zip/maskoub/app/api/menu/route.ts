import { NextRequest, NextResponse } from "next/server";
import { BRANCHES, ITEMS, state, key } from "@/lib/store";

export const dynamic = "force-dynamic";

export function GET(req: NextRequest) {
  const branch = req.nextUrl.searchParams.get("branch") ?? BRANCHES[0].id;
  const all = req.nextUrl.searchParams.get("all") === "1"; // الكاشير يرى كل الأصناف
  const items = ITEMS.map((i) => ({ ...i, off: state.off[key(branch, i.id)] ?? null })).filter((i) => all || !i.off);
  return NextResponse.json({ branches: BRANCHES, items });
}
