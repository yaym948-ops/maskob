"use client";
import { useEffect, useState } from "react";
import type { Branch, Item } from "@/lib/store";

export default function MenuPage() {
  const [branches, setBranches] = useState<Branch[]>([]);
  const [branch, setBranch] = useState("");
  const [items, setItems] = useState<Item[]>([]);

  useEffect(() => {
    const load = async () => {
      const r = await fetch(`/api/menu?branch=${branch}`).then((r) => r.json());
      setBranches(r.branches); setItems(r.items);
      if (!branch) setBranch(localStorage.getItem("branch") || r.branches[0].id);
    };
    load();
    const t = setInterval(load, 15000); // تحديث تلقائي
    return () => clearInterval(t);
  }, [branch]);

  const cats = Array.from(new Set(items.map((i) => i.category)));

  return (
    <div>
      <label className="mb-6 flex items-center gap-3 text-sm">
        الفرع
        <select value={branch} onChange={(e) => { setBranch(e.target.value); localStorage.setItem("branch", e.target.value); }}
          className="rounded border border-pine/30 bg-white px-3 py-2">
          {branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
        </select>
      </label>
      {cats.map((c) => (
        <section key={c} className="mb-8">
          <h2 className="mb-3 border-b-2 border-saffron pb-1 text-xl font-bold text-pine">{c}</h2>
          <ul className="space-y-4">
            {items.filter((i) => i.category === c).map((i) => (
              <li key={i.id}>
                <div className="flex items-baseline gap-2">
                  <span className="font-medium">{i.name}</span>
                  <span className="flex-1 border-b border-dotted border-ink/30" />
                  <span className="font-bold text-pine">{i.price} ر.س</span>
                </div>
                <p className="text-sm text-ink/60">{i.desc}</p>
              </li>
            ))}
          </ul>
        </section>
      ))}
      {items.length === 0 && branch && <p className="text-ink/60">لا توجد أصناف متاحة حاليًا في هذا الفرع.</p>}
    </div>
  );
}
