import type { Metadata } from "next";
import Link from "next/link";
import { IBM_Plex_Sans_Arabic } from "next/font/google";
import "./globals.css";

const plex = IBM_Plex_Sans_Arabic({ subsets: ["arabic"], weight: ["400", "500", "700"], variable: "--font-plex" });
export const metadata: Metadata = { title: "مسكوب", description: "قائمة طعام مسكوب" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body className={`${plex.variable} font-sans`}>
        <header className="bg-pine text-white">
          <div className="mx-auto flex max-w-3xl items-center justify-between px-4 py-3">
            <Link href="/" className="text-2xl font-bold tracking-tight">مسكوب</Link>
            <nav className="flex gap-4 text-sm text-white/80">
              <Link href="/" className="hover:text-saffron">القائمة</Link>
              <Link href="/cashier" className="hover:text-saffron">الكاشير</Link>
              <Link href="/admin" className="hover:text-saffron">الإدارة</Link>
            </nav>
          </div>
        </header>
        <main className="mx-auto max-w-3xl px-4 py-6">{children}</main>
      </body>
    </html>
  );
}
