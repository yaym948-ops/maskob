"use client";
import { useEffect, useState, useCallback } from "react";
import type { Branch, Item, Off } from "@/lib/store";

type Row = Item & { off: Off | null };
const QUICK = ["نفد المخزون", "عطل في المعدات", "الطاهي غير متواجد", "مكوّن ناقص"];

export default function CashierPage() {
  const [branches, setBranches] = useState<Branch[]>([]);
  const [branch, setBranch] = useState("");
  const [items, setItems] = useState<Row[]>([]);
  const [open, setOpen] = useState<string | null>(null);
  const [reason, setReason] = useState("");
  const [name, setName] = useState("");
  const [err, setErr] = useState("");

  const load = useCallback(async (b: string) => {
    const r = await fetch(`/api/menu?all=1&branch=${b}`).then((r) => r.json());
    setBranches(r.branches); setItems(r.items);
  }, []);

  useEffect(() => {
    const b = localStorage.getItem("branch") || "riyadh";
    setBranch(b); setName(localStorage.getItem("cashier") || ""); load(b);
  }, [load]);

  async function send(itemId: string, available: boolean) {
    setErr("");
    const res = await fetch("/api/availability", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ itemId, branchId: branch, available, reason, by: name }),
    });
    const j = await res.json();
    if (!res.ok) return setErr(j.error);
    setOpen(null); setReason(""); load(branch);
  }

  return (
    <div>
      <h1 className="mb-4 text-2xl font-bold text-pine">لوحة الكاشير</h1>
      <div className="mb-6 grid gap-3 sm:grid-cols-2">
        <label className="text-sm">الفرع
          <select value={branch} onChange={(e) => { setBranch(e.target.value); localStorage.setItem("branch", e.target.value); load(e.target.value); }}
            className="mt-1 w-full rounded border border-pine/30 bg-white px-3 py-2">
            {branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
          </select>
        </label>
        <label className="text-sm">اسم الكاشير
          <input value={name} onChange={(e) => { setName(e.target.value); localStorage.setItem("cashier", e.target.value); }}
            className="mt-1 w-full rounded border border-pine/30 bg-white px-3 py-2" placeholder="مثال: خالد" />
        </label>
      </div>

      <ul className="divide-y divide-pine/10 rounded border border-pine/15 bg-white">
        {items.map((i) => (
          <li key={i.id} className="p-4">
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className={i.off ? "text-ink/50 line-through" : "font-medium"}>{i.name}</div>
                {i.off && <div className="text-sm text-chili">متوقف: {i.off.reason}</div>}
              </div>
              {i.off ? (
                <button onClick={() => send(i.id, true)} className="rounded bg-pine px-3 py-2 text-sm text-white">إعادة التوفير</button>
              ) : (
                <button onClick={() => { setOpen(open === i.id ? null : i.id); setReason(""); setErr(""); }}
                  className="rounded border border-chili px-3 py-2 text-sm text-chili">إيقاف الصنف</button>
              )}
            </div>
            {open === i.id && (
              <div className="mt-3 space-y-3 rounded bg-mist p-3">
                <div className="flex flex-wrap gap-2">
                  {QUICK.map((q) => (
                    <button key={q} onClick={() => setReason(q)}
                      className={`rounded-full border px-3 py-1 text-sm ${reason === q ? "border-pine bg-pine text-white" : "border-pine/30 bg-white"}`}>{q}</button>
                  ))}
                </div>
                <input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="أو اكتب السبب"
                  className="w-full rounded border border-pine/30 bg-white px-3 py-2" />
                {err && <p className="text-sm text-chili">{err}</p>}
                <button onClick={() => send(i.id, false)} className="rounded bg-chili px-4 py-2 text-white">تأكيد الإيقاف وإبلاغ الإدارة</button>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
