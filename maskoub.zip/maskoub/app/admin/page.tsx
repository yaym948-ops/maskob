"use client";
import { useEffect, useState, useCallback } from "react";
import type { Notice } from "@/lib/store";

type OffNow = { itemName: string; branchName: string; reason: string; by: string; at: string };
const fmt = (d: string) => new Date(d).toLocaleString("ar-SA", { dateStyle: "short", timeStyle: "short" });

export default function AdminPage() {
  const [notices, setNotices] = useState<Notice[]>([]);
  const [offNow, setOffNow] = useState<OffNow[]>([]);

  const load = useCallback(async () => {
    const r = await fetch("/api/notices").then((r) => r.json());
    setNotices(r.notices); setOffNow(r.offNow);
  }, []);
  useEffect(() => { load(); const t = setInterval(load, 5000); return () => clearInterval(t); }, [load]);

  const markRead = async (id?: string) => {
    await fetch("/api/notices", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id }) });
    load();
  };
  const unread = notices.filter((n) => !n.read).length;

  return (
    <div className="space-y-8">
      <section>
        <h1 className="mb-3 text-2xl font-bold text-pine">لوحة الإدارة</h1>
        <h2 className="mb-2 font-bold">الأصناف المتوقفة الآن ({offNow.length})</h2>
        {offNow.length === 0 ? <p className="text-ink/60">كل الأصناف متاحة في جميع الفروع.</p> : (
          <div className="overflow-x-auto rounded border border-pine/15 bg-white">
            <table className="w-full text-sm">
              <thead className="bg-pine text-white"><tr>
                {["الصنف", "الفرع", "السبب", "بواسطة", "الوقت"].map((h) => <th key={h} className="p-2 text-start font-medium">{h}</th>)}
              </tr></thead>
              <tbody>{offNow.map((o, i) => (
                <tr key={i} className="border-t border-pine/10">
                  <td className="p-2 font-medium">{o.itemName}</td><td className="p-2">{o.branchName}</td>
                  <td className="p-2 text-chili">{o.reason}</td><td className="p-2">{o.by}</td><td className="p-2">{fmt(o.at)}</td>
                </tr>))}</tbody>
            </table>
          </div>
        )}
      </section>

      <section>
        <div className="mb-2 flex items-center justify-between">
          <h2 className="font-bold">الإشعارات {unread > 0 && <span className="me-2 rounded-full bg-chili px-2 py-0.5 text-xs text-white">{unread} جديد</span>}</h2>
          {unread > 0 && <button onClick={() => markRead()} className="text-sm text-pine underline">تعليم الكل كمقروء</button>}
        </div>
        <ul className="space-y-2">
          {notices.map((n) => (
            <li key={n.id} className={`rounded border-s-4 bg-white p-3 ${n.kind === "off" ? "border-chili" : "border-pine"} ${n.read ? "opacity-60" : ""}`}>
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-medium">{n.kind === "off" ? "توقف" : "عودة"} {n.itemName} — {n.branchName}</div>
                  <div className="text-sm text-ink/70">{n.kind === "off" ? `السبب: ${n.reason}` : n.reason} · {n.by} · {fmt(n.at)}</div>
                </div>
                {!n.read && <button onClick={() => markRead(n.id)} className="shrink-0 text-sm text-pine underline">تم</button>}
              </div>
            </li>
          ))}
          {notices.length === 0 && <p className="text-ink/60">لا توجد إشعارات بعد.</p>}
        </ul>
      </section>
    </div>
  );
}
