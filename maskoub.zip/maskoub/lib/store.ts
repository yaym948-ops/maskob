export type Branch = { id: string; name: string };
export type Item = { id: string; name: string; desc: string; price: number; category: string };
export type Off = { reason: string; by: string; at: string };
export type Notice = {
  id: string; itemId: string; itemName: string; branchId: string; branchName: string;
  reason: string; by: string; kind: "off" | "on"; at: string; read: boolean;
};

export const BRANCHES: Branch[] = [
  { id: "riyadh", name: "فرع الرياض" },
  { id: "jeddah", name: "فرع جدة" },
  { id: "dammam", name: "فرع الدمام" },
];

// بيانات تجريبية: عدّلها أو اربطها بقاعدة بيانات
export const ITEMS: Item[] = [
  { id: "1", name: "مسكوب لحم", desc: "أرز بسمتي مع لحم غنم طري وبهارات المسكوب", price: 48, category: "الأطباق الرئيسية" },
  { id: "2", name: "مسكوب دجاج", desc: "دجاج متبّل على أرز مبهّر بالهيل", price: 36, category: "الأطباق الرئيسية" },
  { id: "3", name: "مندي لحم", desc: "لحم مدخّن على الفحم مع أرز المندي", price: 55, category: "الأطباق الرئيسية" },
  { id: "4", name: "سلطة فتوش", desc: "خضار موسمية وخبز مقرمش وسماق", price: 16, category: "المقبلات" },
  { id: "5", name: "حمص بالطحينة", desc: "حمص ناعم بزيت الزيتون", price: 14, category: "المقبلات" },
  { id: "6", name: "شوربة عدس", desc: "عدس أحمر مع الليمون", price: 12, category: "المقبلات" },
  { id: "7", name: "شاي كرك", desc: "شاي بالحليب والهيل", price: 7, category: "المشروبات" },
  { id: "8", name: "قهوة عربية", desc: "قهوة بالهيل والزعفران", price: 9, category: "المشروبات" },
  { id: "9", name: "كنافة", desc: "كنافة ناعمة بالجبن والقطر", price: 18, category: "الحلويات" },
];

type State = { off: Record<string, Off>; notices: Notice[] };
const g = globalThis as unknown as { __maskoub?: State };
// تخزين في ذاكرة السيرفر (يُفقد عند إعادة التشغيل)
export const state: State = (g.__maskoub ??= { off: {}, notices: [] });
export const key = (branchId: string, itemId: string) => `${branchId}:${itemId}`;
