import type { Config } from "tailwindcss";
export default {
  content: ["./app/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: { pine: "#0F3D3A", saffron: "#E8A317", chili: "#C2412D", mist: "#F0F4F1", ink: "#1B2523" },
      fontFamily: { sans: ["var(--font-plex)", "system-ui", "sans-serif"] },
    },
  },
  plugins: [],
} satisfies Config;
